//
//
// Copyright © 2023 THALES. All rights reserved.
//
    

#ifndef CString_h
#define CString_h

// to be moved to util folder. put now here to avoid merge conflict

extern const char* D1CRaspErrorDomain;
extern const char* D1CRaspErrorDescription;

#endif /* CString_h */
