//
//  CInternal.h
//  D1Core
//
// Copyright © 2024 THALES. All rights reserved.
//

#ifndef CInternal_h
#define CInternal_h

#import <openssl/hmac.h>
#import "CString.h"

#endif /* CInternal_h */
